﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFSample.User.Common
{
    public class enums
    {
        /// <summary>
        /// dropDown values.
        /// </summary>
        public static string PROXY_CONN_NAME = "http://jsonplaceholder.typicode.com/posts";
        public enum enumType
        {          
            PlainText=1,
            JSon=2,
            HTML=3
        }
      
      
    }
}
